﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using OPCAutomation;

namespace OpcDaClient1
{
    public partial class Form1 : Form
    {
        OPCServer MyServer;
        OPCGroup MyGroup;
        OPCItem MyItem, MyItem1, MyItem2;



        public Form1()
        {
            InitializeComponent();
 
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
          Form1 frm = new Form1();
            this.Close();
           
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

   
        private void btnConnect_Click(object sender, EventArgs e)
        {
            try
            {
                MyServer = new OPCServer();
                MyServer.Connect(txtServer.Text);
                MyGroup = MyServer.OPCGroups.Add("mygroup");
                MyGroup.IsActive= true;
                MyGroup.IsSubscribed = true;
           
                MyItem = MyGroup.OPCItems.AddItem("Channel_Siemens.Registers.Start", 1);
                MyItem1 = MyGroup.OPCItems.AddItem("Channel_Siemens.Registers.STOP", 1);
                MyItem2 = MyGroup.OPCItems.AddItem("Channel_Siemens.Registers.PUMP", 1);



                txtStatus.Text = "Connected";
                txtStatus.BackColor = Color.Green;
                btnConnect.Enabled = false;
                btnDisconnect.Enabled = true;
                timer1.Enabled = true;
                
            }
            catch(Exception ex)
            {
                txtStatus.Text = "Error Connect! " + ex.Message;
            }
        }
        private void button3_Click(object sender, EventArgs e)
        {
            MyItem.Write(1);
            MyItem1.Write(0);



        }

        private void timer1_Tick(object sender, EventArgs e)
        {
          int i=Convert.ToInt16( MyItem2.Value);
            if (i == 1) { button2.BackColor = Color.Green; }
            else { button2.BackColor = Color.Red; }
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            MyItem1.Write(1);
            MyItem.Write(0);

        }


        private void btnDisconnect_Click(object sender, EventArgs e)
        {
            try
            {
                MyGroup.IsSubscribed = false;
                MyGroup.IsActive = false;                
                MyServer.OPCGroups.RemoveAll();
                MyServer.Disconnect();
                MyServer = null;

                txtStatus.Text = "Disconnected";
                btnConnect.Enabled = true;
                btnDisconnect.Enabled = false;
                txtStatus.BackColor = Color.Red;
               
            }
            catch (Exception ex)
            {
                txtStatus.Text = "Error Disconnect! " + ex.Message;
            }
        }

        
       
    }
}
